<!DOCTYPE html>
<html lang="en">
<head>
    <title>{{$data['title']}}</title>
</head>
<body>
    <p>{{$data['body']}}</p>
    <a href="{{ $data['url']}}">Click here to reset password.</a>
</body>
</html>