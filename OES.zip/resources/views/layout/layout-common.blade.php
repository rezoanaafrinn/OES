<!DOCTYPE html>
<html lang="en">
<head>
    <title>OES</title>
</head>
<body>
    @yield('space-work')
</body>
</html>