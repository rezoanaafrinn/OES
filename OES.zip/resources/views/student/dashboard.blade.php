<h1>Student Dashboard</h1>
<a href = "/logout">Logout</a>