<!DOCTYPE html>
<html lang="en">
<head>
    <title>OES</title>
</head>
<body>
    <?php echo $__env->yieldContent('space-work'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\OES\resources\views/layout/layout-common.blade.php ENDPATH**/ ?>